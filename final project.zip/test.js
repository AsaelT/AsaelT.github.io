document.querySelector(".card1").addEventListener("click", function () {
    this.classList.toggle("is-flipped");
  });
  
  document.querySelector(".card2").addEventListener("click", function () {
    this.classList.toggle("is-flipped");
  });
  